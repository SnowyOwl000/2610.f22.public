#include <iostream>
#include <fstream>
#include "codec.h"

using namespace std;

bool isPrime(uint64_t n) {

}

int64_t modInverse(int64_t a,int64_t b) {

}

uint64_t modExp(uint64_t base,uint64_t exp,uint64_t mod) {

}

void keyGen() {

}

void encrypt(char *inFileName,char *outFileName,int64_t n,int64_t e) {

}

void decrypt(char *inFileName,char *outFileName,int64_t n,int64_t d) {

}

int main(int argc,char *argv[]) {

    return 0;
}
